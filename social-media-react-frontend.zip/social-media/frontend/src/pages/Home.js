import { useEffect, useState } from 'react';
import axios from 'axios';
import Post from '../components/Post';

const Home = () => {
    const [posts, setPosts] = useState([]);
    const [content, setContent] = useState('');

    const fetchPosts = async () => {
        const res = await axios.get('http://localhost:5000/posts');
        setPosts(res.data);
    };

    useEffect(() => {
        fetchPosts();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post('http://localhost:5000/posts', { 
            username: 'User', 
            content 
        });
        setContent('');
        fetchPosts();
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <input 
                    type="text" 
                    value={content} 
                    onChange={(e) => setContent(e.target.value)} 
                    placeholder="What's on your mind?"
                />
                <button type="submit">Post</button>
            </form>
            {posts.map((post) => (
                <Post key={post._id} post={post} refreshPosts={fetchPosts} />
            ))}
        </div>
    );
};

export default Home;
