import { useState } from 'react';
import axios from 'axios';

const Post = ({ post, refreshPosts }) => {
    const [comment, setComment] = useState('');

    const handleLike = async () => {
        await axios.put(`http://localhost:5000/posts/${post._id}/like`);
        refreshPosts();
    };

    const handleComment = async () => {
        await axios.post(`http://localhost:5000/posts/${post._id}/comment`, { 
            username: 'User', 
            text: comment 
        });
        setComment('');
        refreshPosts();
    };

    return (
        <div style={{ border: '1px solid #ccc', padding: '10px', marginBottom: '10px' }}>
            <p><strong>{post.username}</strong></p>
            <p>{post.content}</p>
            <button onClick={handleLike}>Like ({post.likes})</button>
            <div>
                <input 
                    type="text" 
                    value={comment} 
                    onChange={(e) => setComment(e.target.value)} 
                    placeholder="Add a comment..." 
                />
                <button onClick={handleComment}>Comment</button>
            </div>
            <ul>
                {post.comments.map((c, index) => (
                    <li key={index}><strong>{c.username}:</strong> {c.text}</li>
                ))}
            </ul>
        </div>
    );
};

export default Post;
